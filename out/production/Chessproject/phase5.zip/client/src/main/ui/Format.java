package ui;

import java.util.Scanner;

import chess.Board;
import chess.Piece;
import chess.Position;
import chess.ChessGame.TeamColor;

import java.io.PrintStream;

import static ui.EscapeSequences.*;

public class Format {
    private PrintStream out;
    boolean toggleLetters = false;
    
    public Format(PrintStream out) {
        this.out = out;
    }

    public String getInput(){
        out.print(SET_TEXT_COLOR_WHITE);
        Scanner s = new Scanner(System.in);
        String line = s.nextLine();
        out.print(SET_TEXT_COLOR_BLUE);
        return line;
        
    }

    public String entryfield(String prompt){
        out.print(SET_TEXT_BOLD);
        out.print(prompt + ":");
        out.print(RESET_TEXT_BOLD_FAINT);
        String result = getInput();
        out.print(SET_TEXT_COLOR_BLUE);
        return result;
    }

    public void title(){
        out.print(SET_BG_COLOR_BLACK);
        out.print(SET_TEXT_BLINKING);
        out.print(SET_TEXT_COLOR_GREEN);
        out.print(SET_TEXT_BOLD);
        out.print(WHITE_QUEEN);
        out.print(" Welcome to Makenna's Chess Server!");
        out.print(WHITE_QUEEN);
        out.print("\n\n\n");
        out.print(RESET_TEXT_BOLD_FAINT);
        out.print(RESET_TEXT_BLINKING);
        out.print(SET_TEXT_COLOR_BLUE);
    }

    public void toggleLetters(){
        if (toggleLetters){
            toggleLetters = false;
            out.print("Changed to chess pieces.\n");
        }
        else{
            toggleLetters = true;
            out.print("Changed to letters\n");
        }
    }

    public void errormsg(String message){
        out.print(SET_TEXT_BLINKING);
        out.print(SET_TEXT_COLOR_RED);
        out.print(SET_TEXT_BOLD);
        out.print(message);
        out.print(SET_TEXT_COLOR_BLUE);
        out.print(RESET_TEXT_BLINKING);
        out.print(RESET_TEXT_BOLD_FAINT);
    }

    public void printGame(Board game){
        String header;
        if (toggleLetters){
            header = " a  b  c  d  e  f  g  h \n";
        }
        else{
            header = "  a   b   c   d   e   f   g   h\n";
        }
        out.print(header);
        for(int i = 1; i< 9; i++){
            out.print(String.valueOf(i));
            for (int j = 1; j < 9; j++){
                if ((i%2==0 && j%2==0) || (i%2==1 && j%2==1)){
                    out.print(SET_BG_COLOR_DARK_GREEN);
                }
                else{
                    out.print(SET_BG_COLOR_LIGHT_GREY);
                }
                if (toggleLetters){
                    out.print(" ");
                }
                Piece piece = (Piece) game.getPiece(new Position(i, j));
                printPiece(piece);
            }
            out.print(SET_BG_COLOR_BLACK);
            out.print(String.valueOf(i) + "\n");
        }
        out.print(header);
    }
    
    public void printPiece(Piece piece){
        if (piece == null){
            if (toggleLetters){
                out.print(" ");
            }
            else{
                out.print("   ");
            }
        }
        else if (piece.getTeamColor() == TeamColor.BLACK){
            out.print(SET_TEXT_COLOR_BLACK);
            if (toggleLetters){
                out.print(piece.toString());
            }
            else{
                switch (piece.getPieceType()) {
                    case PAWN:
                    out.print(BLACK_PAWN);
                    break;
                    case BISHOP:
                    out.print(BLACK_BISHOP);
                    break;
                    case KNIGHT:
                        out.print(BLACK_KNIGHT);
                        break;
                    case ROOK:
                        out.print(BLACK_ROOK);
                        break;
                    case KING:
                        out.print(BLACK_KING);
                        break;
                    case QUEEN:
                    out.print(BLACK_QUEEN);
                    break;
                    default:
                    break;
                }
            }
        }
        else{
            out.print(SET_TEXT_COLOR_WHITE);
            if (toggleLetters){
                out.print(piece.toString());
            }
            else{
                switch (piece.getPieceType()) {
                    case PAWN:
                        out.print(WHITE_PAWN);
                        break;
                    case BISHOP:
                        out.print(WHITE_BISHOP);
                        break;
                    case KNIGHT:
                    out.print(WHITE_KNIGHT);
                    break;
                    case ROOK:
                    out.print(WHITE_ROOK);
                    break;
                    case KING:
                    out.print(WHITE_KING);
                    break;
                    case QUEEN:
                    out.print(WHITE_QUEEN);
                    break;
                    default:
                    break;
                }
            }
        }
        out.print(" ");
        out.print(SET_TEXT_COLOR_BLUE);
    }
}
