import model.AuthToken;
import model.UserGame;
import serverFacade.*;

import java.io.PrintStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import chess.Board;
import ui.Format;
import static ui.EscapeSequences.*;

public class ClientMain {
    
    private static PrintStream out = new PrintStream(System.out,true, StandardCharsets.UTF_8);
    private static Format format = new Format(out);
    private static String serverURL = "http://localhost:8080";
    private static final String URI_ERROR_MSG = "Could not connect to URL. Please restart the program and try again.\n";
    

    public static void main(String[] args){
        if (args.length == 1){
            serverURL = args[0];
        }
        String input = "help";
        out.print(ERASE_SCREEN);
        format.title();
        prelogin(input);  
    }

    private static void prelogin(String input){
        while (!input.equals("quit")){
            if (input.equals("login")){
                String name = format.entryfield("Username");
                String password = format.entryfield("Password");
                out.print(ERASE_SCREEN);
                try{
                    ServerFacade login = new ServerFacade(serverURL);
                    AuthToken token = login.login(name, password);
                    if (token != null){
                        postlogin(token);
                    }
                    else{
                        format.errormsg("Your username or password is incorrect.\n");
                    }
                }
                catch (URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch (ConnectionException e){
                    format.errormsg(e.getMessage());
                }
                out.print(RESET_TEXT_BOLD_FAINT);
                format.title();
            }
            else if (input.equals("register")){
                String username = format.entryfield("Username");
                String email = format.entryfield("Email");
                String password = format.entryfield("Password");
                out.print(ERASE_SCREEN);
                try{
                    ServerFacade register = new ServerFacade(serverURL);
                    AuthToken token = register.register(username, password, email);
                    if (token != null){
                        postlogin(token);
                    }
                    else{
                        format.errormsg("That username is already taken. Please try something else.\n");
                    }
                }
                catch (URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch (ConnectionException e){
                    format.errormsg(e.getMessage());
                }
                format.title();
            }
            //help
            else if (input.equals("help")){
                out.print("****OPTIONS****\n");
                out.print("Type \"help\" for options\n");
                out.print("Type \"quit\" to exit\n");
                out.print("Type \"register\" for a account\n");
                out.print("Type \"login\" to an exsisting account\n");
            }
            else{
                out.print("\n" + input + " is not recognized. Type \"help\" for options\n\n");
            }
            input = format.getInput();
        }
       return;
    }

    private static void postlogin(AuthToken token){
        String input = "help";
        while (!(input.equals("logout") || input.equals("quit"))){
            if (input.equals("help")){
                out.print("****OPTIONS****\n");
                out.print("Type \"help\" for options\n");
                out.print("Type \"logout\" to logout\n");
                out.print("Type \"quit\" to exit\n"); //TODO IMPL
                out.print("Type \"create\" to make a new game\n");
                out.print("Type \"list\" to see the list of exsisting games\n");
                out.print("Type \"join\" to join a game\n");
                out.print("Type \"observe\" to watch a game\n");
                out.print("Type\"pieces\" to change the pieces to letters, or change back\n");
            }
            else if (input.equals("pieces")){
                format.toggleLetters();
            }
            else if (input.equals("create")){
                String name = format.entryfield("Game Name");
                try{
                    ServerFacade create = new ServerFacade(serverURL);
                    int id = create.createGame(name, token.getAuthToken());
                    out.print("Successfully created game " + name + ".\n");
                    out.print("ID number is " + String.valueOf(id)+ "\n");
                }
                catch (URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch (ConnectionException e){
                    format.errormsg(e.getMessage());
                }
            }
            else if (input.equals("list")){
                try{
                    ServerFacade list = new ServerFacade(serverURL);
                    ArrayList<UserGame> games = (ArrayList<UserGame>) list.list(token.getAuthToken());
                    //table headers
                    out.print(SET_TEXT_COLOR_MAGENTA);
                    out.print(SET_TEXT_BOLD);
                    out.print(String.valueOf("ID "));
                    out.print(SET_TEXT_COLOR_YELLOW);
                    out.print("GAME NAME ");
                    out.print(SET_TEXT_COLOR_WHITE);
                    out.print("WHITE TEAM ");
                    out.print(SET_BG_COLOR_WHITE);
                    out.print(SET_TEXT_COLOR_BLACK);
                    out.print("BLACK TEAM\n");
                    out.print(SET_BG_COLOR_BLACK);
                    out.print(RESET_TEXT_BOLD_FAINT);
                    for (UserGame game : games){
                        out.print(SET_TEXT_COLOR_MAGENTA);
                        out.print(String.valueOf(game.getGameID())+ " ");
                        out.print(SET_TEXT_COLOR_YELLOW);
                        out.print(game.getGameName()+ " ");
                        out.print(SET_TEXT_COLOR_WHITE);
                        String username = game.getWhiteUsername();
                        if (username != null){
                            out.print(username + " ");
                        }
                        else {
                            out.print("AVAILABLE ");
                        }
                        out.print(SET_BG_COLOR_WHITE);
                        out.print(SET_TEXT_COLOR_BLACK);
                        username = game.getBlackUsername();
                        if (username != null){
                            out.print(username);
                        }
                        else {
                            out.print("AVAILABLE");
                        }
                        out.print(SET_BG_COLOR_BLACK);
                        out.print("\n");
                    }
                    out.print(SET_TEXT_COLOR_BLUE);
                }
                catch (URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch (ConnectionException e){
                    format.errormsg(e.getMessage());
                }
            }
            else if (input.equals("join")){
                String ID = format.entryfield("Game ID");
                int id = 0;
                do{
                    try{
                        id = Integer.parseInt(ID);
                    }
                    catch (NumberFormatException e){
                        format.errormsg(ID + " is not a valid id. Please try again.\n");
                        ID = format.getInput();
                    }
                }
                while (id <= 0);
                String team = format.entryfield("Which side would you like to join? (white/black)");
                team = team.toUpperCase();
                while (!(team.equals("WHITE")||team.equals("BLACK"))){
                    format.errormsg(team + " is not a valid team. Please choose black or white.\n");
                    team = format.getInput();
                }

                try{
                    ServerFacade join = new ServerFacade(serverURL);
                    join.join(token.getAuthToken(),id,team);
                    //WEBSOCKETS
                    Board board = new Board();
                    board.resetBoard();
                    format.printGame(board);
                }
                catch(URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch(ConnectionException e){
                    format.errormsg(e.getMessage());
                }

            }
            else if (input.equals("observe")){
                String ID = format.entryfield("GameID");
                int id = 0;
                do{
                    try{
                        id = Integer.parseInt(ID);
                    }
                    catch (NumberFormatException e){
                        format.errormsg(ID + " is not a valid id. Please try again.\n");
                        ID = format.getInput();
                    }
                } while (id <= 0);

                try{
                    ServerFacade observe = new ServerFacade(serverURL);
                    observe.join(token.getAuthToken(), id, "");
                    //WEBSOCKETS
                    Board board = new Board();
                    board.resetBoard();
                    format.printGame(board);
                }
                catch(URISyntaxException e){
                    format.errormsg(URI_ERROR_MSG);
                }
                catch(ConnectionException e){
                    format.errormsg(e.getMessage());
                }
            }
            else{
                out.print("\n" + input + " is not recognized. Type \"help\" for options\n\n");
            }
            input = format.getInput();
        }
        //logout handler
        if (input.equals("logout")){
            try{
                new ServerFacade(serverURL).logout(token.getAuthToken());
            }
            catch (URISyntaxException e){
                format.errormsg(URI_ERROR_MSG);
            }
            catch (ConnectionException e){
                format.errormsg(e.getMessage());
            }
        }
    }    
}
