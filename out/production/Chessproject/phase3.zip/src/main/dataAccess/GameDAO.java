package dataAccess;

import java.util.HashSet;
import java.util.Collection;

import model.UserGame;

/**Game Data Access Object
 * <p> manages games within the database
 */
public class GameDAO {
    
    private static Collection<UserGame> games = new HashSet<>();

    
    public Collection<UserGame> getGames() {
        Collection<UserGame> copy = new HashSet<>();
        for(UserGame game : games){
            copy.add(game);
        }        
        return copy;
    }

    /**Removes all games from the database */
    public void clear() throws DataAccessException{
        games.clear();
    }

    /**
     * returns the games in the database
     * 
     * @return Collection of games
     */
    public Collection<UserGame> listAll(){
        return games;
    }

    /**
     * puts given Game in the database
     * 
     * @param userGame
     * @throws DataAccessException when gamename is already taken
     */
    public void insert(UserGame userGame) throws DataAccessException{
        try{
            find(userGame.getGameID());
        }
        catch(DataAccessException e){
            if (e.getMessage().equals("not found")){
                games.add(userGame);
                return;
            }
        }
        throw new DataAccessException("already taken");
    }

    /**
     * finds game in database
     * 
     * @param gameID
     * @return Usergame object with matching game ID
     * @throws DataAccessException if not found
     */
    public UserGame find(int gameID) throws DataAccessException{
        for (UserGame game : games){
            if (gameID == game.getGameID()){
                return game;
            }
        }
        throw new DataAccessException("not found");
    }

    /**
     * finds game in database
     * 
     * @param gameName
     * @return Usergame object with matching game name
     * @throws DataAccessException if not found
     */
    public UserGame find (String gameName) throws DataAccessException{
        for (UserGame game : games){
            if (gameName.equals(game.getGameName())){
                return game;
            }
        }
        throw new DataAccessException("not found");
    }


}
