package dataAccess;

import java.util.HashSet;
import java.util.Collection;
import model.User;

/**User Data Access Object
 * <p> manages users within the database
 */
public class UserDAO {
    
    private static Collection<User> users = new HashSet<>();
    
    public Collection<User> getUsers() {
        Collection<User> copy = new HashSet<>();
        for(User user :users){
            copy.add(user);
        }
        return copy;
    }

    /**Removes all users from the database */
    public void clear() throws DataAccessException{
        users.clear();
    }

    /**
     * Inserts a User object in the database<p>
     * 
     * @param user
     * @throws DataAccessException if the user already exsists
     */
    public void insert(User user) throws DataAccessException{
        try{
            find(user.getUserName());
        }
        catch (DataAccessException e){
            if (e.getMessage() == "not found"){
                users.add(user);
                return;
            }
        }
        throw new DataAccessException("already taken");
    }

    /**
     * 
     * @param username
     * @return User with username
     * @throws DataAccessException if it could not find it
     */
    public User find(String username) throws DataAccessException{
        for (User user : users){
            if (username.equals(user.getUserName())){
                //System.out.println("found");
                return user;
            }
        }
        throw new DataAccessException("not found");
    }


}
