package dataAccess;

import java.util.Collection;
import java.util.HashSet;

import model.AuthToken;

/**Authentication Token Data Access Object
 * <p> manages tokens within the database
 */
public class AuthDAO {
    
    private static Collection<AuthToken> tokens = new HashSet<>();
    String lastGenerated = "abc";

    public Collection<AuthToken> getTokens() {
        Collection<AuthToken> copy = new HashSet<>();
        for (AuthToken token : tokens){
            copy.add(token);
        }
        return copy;
    }
    
    /**Removes all auth tokens from the database */
    public void clear() throws DataAccessException{
        tokens.clear();
    }

    /**
     * inserts authToken object into the database
     * 
     * @param authToken
     * @throws DataAccessException - if the authToken already exists
     */
    public void insert(AuthToken authToken) throws DataAccessException{
        if (authToken.getAuthToken() == null){
            throw new DataAccessException("tried to insert a blank auth token");
        }
        try{
            findToken(authToken.getAuthToken());
        }
        catch(DataAccessException e){
            tokens.add(authToken);
            return;
        }
        throw new DataAccessException("already taken");
    }

    /**
     * finds authToken in the database
     * 
     * @param userName
     * @return Authtoken matching username
     * @throws DataAccessException - when not found
     */
    public AuthToken findName(String userName) throws DataAccessException{
        for (AuthToken token : tokens){
            if (token.getUserName().equals(userName)){
                return token;
            }
        }
        throw new DataAccessException("not found");
    }

    /**
     * finds authToken in the database
     * 
     * @param authToken
     * @return Authoken matching token
     * @throws DataAccessException - when not found
     */
    public AuthToken findToken(String authToken) throws DataAccessException{
        for (AuthToken token : tokens){
            if (token.getAuthToken().equals(authToken)){
                return token;
            }
        }
        throw new DataAccessException("not found");
    }

    /**
     * removes authToken from database
     * 
     * @param authToken - String
     * @throws DataAccessException if authToken is not in the database
     */
    public void remove(String authToken) throws DataAccessException{
        AuthToken deleteMe = findToken(authToken);
        tokens.remove(deleteMe);
    }

    public String genAuthToken(String user){
        AuthToken auth = new AuthToken(user, changeToken());
        try{
            insert(auth);
        }
        catch(DataAccessException e){
            System.out.println("your token change function is broken");
        }
        return lastGenerated;
    }

    public String changeToken(){
        try{
            while(findToken(lastGenerated)!= null){
                char addme = lastGenerated.charAt(lastGenerated.length()-1);
                //System.out.println(addme);
                if (addme == 'z'){
                    lastGenerated = lastGenerated+"A";
                }
                else{
                    lastGenerated = lastGenerated.replace(addme, ++addme);
                }
            }
        }
        catch (DataAccessException e){
            return lastGenerated;
        }
        return null;
    }
}
