package model;

import chess.GameImpl;

/**runs a chess.game, as well as IDs, names and assigns users and observers */
public class UserGame {
    private int gameID;
    private String whiteUsername;
    private String blackUsername;
    private String gameName;
    private GameImpl game;

    private static int lastGenerated = 1;

    
    /**
     * Creates a new game with an id
     * 
     * @param name - Game name
     */
    public UserGame(String name){
        gameName = name;
        gameID = lastGenerated;//TODO generate a better game ID
        changeID();
        game = new GameImpl();//TODO: make sure the board is set up
    }

    public int getGameID() {
        return gameID;
    }

    public String getBlackUsername() {
        return blackUsername;
    }

    public String getWhiteUsername() {
        return whiteUsername;
    }

    public String getGameName() {
        return gameName;
    }

    public void setBlackUsername(String blackUsername) {
        this.blackUsername = blackUsername;
    }

    public void setWhiteUsername(String whiteUsername) {
        this.whiteUsername = whiteUsername;
    }

    public void changeID(){
        lastGenerated++;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + gameID;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserGame other = (UserGame) obj;
        if (gameID != other.gameID)
            return false;
        return true;
    }
}
